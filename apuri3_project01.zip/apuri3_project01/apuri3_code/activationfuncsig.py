#!/usr/bin/env python
# -*- coding: utf-8 -*-
# File: activationfuncsig.py

import numpy as np

def sigmoid(z):
    """The sigmoid function."""
    
    return (1/(1+np.exp(-z.astype(np.float64))))


def main():
    '''foooooooooo'''
if __name__ == main():
    main()